ansible-playbook nginx.yml -i inventory -e "target_server='$1'"
